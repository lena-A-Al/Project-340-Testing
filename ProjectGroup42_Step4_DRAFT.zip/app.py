
from flask import Flask,render_template, json, redirect,request
from flask_mysqldb import MySQL
from database import db_connector
# import database.db_connector as db
import os


# database connection info
app = Flask(__name__)

app.config['MYSQL_HOST'] = 'classmysql.engr.oregonstate.edu'
app.config['MYSQL_USER'] = 'cs340_palaquie'
app.config['MYSQL_PASSWORD'] = '5283' #last 4 of onid
app.config['MYSQL_DB'] = 'cs340_palaquie'
app.config['MYSQL_CURSORCLASS'] = "DictCursor"


mysql = MySQL(app)



###----------------------------------Routes---------------------------------------#

#---------------------------------Homepage Request--------------------------------#

@app.route('/')
def index():
    return render_template('/index.html')


#---------------------------------Employee Get Request----------------------------#
@app.route('/employees')
def employees():
    print("Fetching and rending employees web page")
    db_connection = db_connector.connect_to_database()
    query = "SELECT * from employees;"
    result = db_connector.execute_query(db_connection, query).fetchall()
    print('results employees')    
    return render_template('employees.html', employees=result) 
#---------------------------------------------------------------------------------#
#---------------------------------Employee Add request----------------------------#
@app.route('/add_employee', methods =['POST','GET'])
def add_employees():
    db_connection = db_connector.connect_to_database()

    if request.method == 'POST':
        print('adding employee')
        manager_id = request.form['manager_id']
        employee_name = request.form['employee_name']
        organization = request.form['organization']
        query = "INSERT INTO employees(manager_id, employee_name, organization) VALUES (%s,%s,%s);"
        data=(manager_id, employee_name, organization)
        db_connector.execute_query(db_connection, query, data).fetchall()
        return redirect("/employees")
    else:
        return render_template('add_employee.html')
#---------------------------------------------------------------------------------#

#---------------------------------Employee Delete request-------------------------#
@app.route('/delete_employee/<int:id>')
def delete_employees(id):
    db_connection = db_connector.connect_to_database()


    query="DELETE FROM employees WHERE employee_id = %s;"
    data = (id,)
    db_connector.execute_query(db_connection, query, data)
    return redirect("/employees")
#--------------------------------------------------------------------------------#

#---------------------------------Employee Update request------------------------#
@app.route('/update_employee/<int:id>', methods = ["POST", "GET"])
def update_employees(id):
    db_connection = db_connector.connect_to_database()

    if request.method == "POST":
        """ """
        return redirect("/employees")
    else:
        data1 = (id)
        # Select Single employee
        query = "SELECT * FROM employees WHERE employee_id = %s;"
        curr_employee = db_connector.execute_query(db_connection, query, data1).fetchall()
        
        return render_template("/update_employee.html", selected_employee = curr_employee,  )
        

#--------------------------------------------------------------------------------#







#---------------------------------projects Get request---------------------------#
@app.route('/projects')
def projects():
    #Fetching and rendering list of projects
    db_connection = db_connector.connect_to_database()
    query = "SELECT * from projects;"
    result = db_connector.execute_query(db_connection, query).fetchall()
    print('results projects')    
    return render_template('projects.html', projects=result)
#--------------------------------------------------------------------------------#

#---------------------------------Project Add request----------------------------#
#---------------------------------Project Delete request-------------------------#
#---------------------------------Project Update request-------------------------#







#---------------------------------Clients Get request----------------------------#
@app.route('/clients')
def clients():
    db_connection = db_connector.connect_to_database()
    query = "SELECT * from clients;"
    result = db_connector.execute_query(db_connection, query).fetchall()

    return render_template('clients.html', clients=result)
#--------------------------------------------------------------------------------#
#---------------------------------Client Add request-----------------------------#
#---------------------------------Client Delete request--------------------------#
#---------------------------------Client Update request--------------------------#








#---------------------------------Manager Get request----------------------------#
@app.route('/managers')
def managers():
    db_connection = db_connector.connect_to_database()
    query = "SELECT * from managers;"
    result = db_connector.execute_query(db_connection, query).fetchall()
     
    return render_template('managers.html', managers= result) 
#---------------------------------Manager Add request----------------------------#
#---------------------------------Manager Delete request-------------------------#
#---------------------------------Manager Update request-------------------------#

#--------------------------------------------------------------------------------#







#-------------------------------Projects_mapping Get request---------------------#
@app.route('/projects_mapping')
def projects_mapping():
    db_connection = db_connector.connect_to_database()
    query = "SELECT * from projects_mapping;"
    result = db_connector.execute_query(db_connection, query).fetchall()

    return render_template('projects_mapping.html', projects_mapping = result)
#--------------------------------------------------------------------------------#
#---------------------------------Project_mapping Add request--------------------#
#---------------------------------Project_mapping Delete request-----------------#
#---------------------------------Project_mapping Update request-----------------#
#--------------------------------------------------------------------------------#

if __name__ == "__main__":
    port = int(os.environ.get('PORT', 42543))
    app.run(port=port, debug=True)